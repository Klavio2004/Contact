package com.example.contactapp.data

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface ContactDao {

    @Insert
    suspend fun insert(contact: Contact)

    @Update
    suspend fun update(contact: Contact)

    @Delete
    suspend fun delete(contact: Contact)

    @Query("DELETE FROM contacts WHERE id = :id")
    suspend fun deleteById(id: Int)

    @Query("SELECT * FROM contacts ORDER BY firstName ASC")
    fun getAllContacts(): LiveData<List<Contact>>

    @Query("SELECT * FROM contacts WHERE id = :id LIMIT 1")
    fun getContactById(id: Int): LiveData<Contact>

    @Query("""
        SELECT * FROM contacts
        WHERE firstName LIKE :query OR lastName LIKE :query
        ORDER BY firstName ASC
    """)
    fun searchContacts(query: String): LiveData<List<Contact>>
}


package com.example.contactapp.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.example.contactapp.data.AppDatabase
import com.example.contactapp.data.Contact
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ContactViewModel(application: Application) : AndroidViewModel(application) {

    private val contactDao = AppDatabase.getDatabase(application).contactDao()
    val allContacts: LiveData<List<Contact>> = contactDao.getAllContacts()

    fun insert(contact: Contact) = viewModelScope.launch(Dispatchers.IO) {
        contactDao.insert(contact)
    }

    fun update(contact: Contact) = viewModelScope.launch(Dispatchers.IO) {
        contactDao.update(contact)
    }

    fun delete(contact: Contact) = viewModelScope.launch(Dispatchers.IO) {
        contactDao.delete(contact)
    }

    fun search(query: String): LiveData<List<Contact>> {
        return contactDao.searchContacts("%$query%")
    }

    fun getContact(id: Int): LiveData<Contact> {
        return contactDao.getContactById(id)
    }

    fun deleteById(id: Int) = viewModelScope.launch(Dispatchers.IO) {
        contactDao.deleteById(id)
    }
}

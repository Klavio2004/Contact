package com.example.contactapp

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.contactapp.adapter.ContactAdapter
import com.example.contactapp.viewmodel.ContactViewModel
import com.google.android.material.floatingactionbutton.FloatingActionButton
import androidx.core.widget.addTextChangedListener

class MainScreen : AppCompatActivity() {

    private val viewModel: ContactViewModel by viewModels {
        androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.getInstance(application)
    }
    private lateinit var adapter: ContactAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_screen)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        val etSearch = findViewById<EditText>(R.id.etSearch)
        val fabAdd = findViewById<FloatingActionButton>(R.id.fabAdd)


        adapter = ContactAdapter { contact ->
            val intent = Intent(this, CRUDform::class.java)
            intent.putExtra("contactId", contact.id)
            startActivity(intent)
        }

        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        viewModel.allContacts.observe(this) { list ->
            adapter.submitList(list)
        }

        etSearch.addTextChangedListener { editable ->
            val query = editable.toString()
            val source = if (query.isEmpty()) {
                viewModel.allContacts
            } else {
                viewModel.search(query)
            }

            source.observe(this) { list ->
                adapter.submitList(list)
            }
        }


        // Add new contact
        fabAdd.setOnClickListener {
            val intent = Intent(this, CRUDform::class.java)
            startActivity(intent)
        }
    }
}

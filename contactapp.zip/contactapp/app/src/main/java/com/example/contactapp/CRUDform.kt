package com.example.contactapp

import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.contactapp.data.Contact
import com.example.contactapp.viewmodel.ContactViewModel

class CRUDform : AppCompatActivity() {

    private val viewModel: ContactViewModel by viewModels {
        androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.getInstance(application)
    }

    private lateinit var etFirstName: EditText
    private lateinit var etLastName: EditText
    private lateinit var etCompany: EditText
    private lateinit var etPhone: EditText
    private lateinit var etEmail: EditText

    private lateinit var btnCancel: TextView
    private lateinit var btnSave: TextView
    private lateinit var btnDelete: TextView

    private var contactId = 0
    private var editing = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.crud_form)


        etFirstName = findViewById(R.id.etFirstName)
        etLastName = findViewById(R.id.etLastName)
        etCompany = findViewById(R.id.etCompany)
        etPhone = findViewById(R.id.etPhone)
        etEmail = findViewById(R.id.etEmail)

        btnCancel = findViewById(R.id.btnCancel)
        btnSave = findViewById(R.id.btnSave)
        btnDelete = findViewById(R.id.btnDelete)


        contactId = intent.getIntExtra("contactId", 0)
        editing = contactId != 0


        btnDelete.visibility = if (editing) TextView.VISIBLE else TextView.GONE


        if (editing) {
            viewModel.getContact(contactId).observe(this) { contact ->
                contact?.let {
                    etFirstName.setText(it.firstName)
                    etLastName.setText(it.lastName)
                    etCompany.setText(it.company)
                    etPhone.setText(it.phone)
                    etEmail.setText(it.email)
                }
            }
        }

        btnCancel.setOnClickListener {
            finish()
        }

        btnSave.setOnClickListener {
            saveContact()
            finish()
        }

        btnDelete.setOnClickListener {
            showDeleteConfirmation()
        }
    }

    private fun saveContact() {
        val contact = Contact(
            id = if (editing) contactId else 0,
            firstName = etFirstName.text.toString(),
            lastName = etLastName.text.toString(),
            company = etCompany.text.toString(),
            phone = etPhone.text.toString(),
            email = etEmail.text.toString()
        )

        if (editing) {
            viewModel.update(contact)
        } else {
            viewModel.insert(contact)
        }
    }
    private fun showDeleteConfirmation() {
        val dialog = AlertDialog.Builder(this, R.style.iOSAlertDialog)
            .setTitle("Διαγραφή Επαφής")
            .setMessage("Θέλεις σίγουρα να διαγράψεις αυτή την επαφή;")
            .setNegativeButton("Άκυρο", null)
            .setPositiveButton("Διαγραφή") { _, _ ->
                viewModel.deleteById(contactId)
                finish()
            }
            .create()

        dialog.show()

        dialog.getButton(AlertDialog.BUTTON_POSITIVE)
            .setTextColor(getColor(android.R.color.holo_red_dark))

        dialog.getButton(AlertDialog.BUTTON_NEGATIVE)
            .setTextColor(getColor(android.R.color.darker_gray))
    }
//    private fun showDeleteConfirmation() {
//        AlertDialog.Builder(this)
//            .setTitle("Διαγραφή Επαφής")
//            .setMessage("Θέλεις σίγουρα να διαγράψεις αυτή την επαφή;")
//            .setPositiveButton("Διαγραφή") { _, _ ->
//                viewModel.deleteById(contactId)
//                finish()
//            }
//            .setNegativeButton("Άκυρο", null)
//            .show()
//    }
}
